import './App.css';
import { AppRoutes } from './pages/routes'

function App() {
  return (
    <div>
      <AppRoutes/>
    </div>
  );
}

export default App;
